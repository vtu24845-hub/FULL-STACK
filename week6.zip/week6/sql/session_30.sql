-- Session 30: User Auth with JWT
-- Database: session30_db

CREATE DATABASE IF NOT EXISTS session30_db;
USE session30_db;

CREATE TABLE IF NOT EXISTS users (
    id BIGINT AUTO_INCREMENT PRIMARY KEY,
    name VARCHAR(255) NOT NULL,
    email VARCHAR(255) NOT NULL UNIQUE,
    age INT NOT NULL,
    username VARCHAR(255) NOT NULL,
    password VARCHAR(255) NOT NULL
);

-- Sample data
INSERT INTO users (name, email, age, username, password) VALUES
('Alice Smith', 'alice@example.com', 25, 'alice', 'password123'),
('Bob Jones', 'bob@example.com', 30, 'bob', 'password456');
