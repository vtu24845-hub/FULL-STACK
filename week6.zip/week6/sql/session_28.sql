-- Session 28: PUT and DELETE HTTP methods
-- Database: session28_db

CREATE DATABASE IF NOT EXISTS session28_db;
USE session28_db;

CREATE TABLE IF NOT EXISTS products (
    id BIGINT AUTO_INCREMENT PRIMARY KEY,
    name VARCHAR(255) NOT NULL,
    description VARCHAR(255) NOT NULL,
    price DOUBLE NOT NULL,
    quantity INT NOT NULL
);

-- Sample data
INSERT INTO products (name, description, price, quantity) VALUES
('Laptop', 'High performance laptop', 999.99, 10),
('Mouse', 'Wireless mouse', 29.99, 50),
('Keyboard', 'Mechanical keyboard', 79.99, 30);
